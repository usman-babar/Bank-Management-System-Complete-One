package application;

import java.io.IOException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AllUserController {

	Bank m = new Bank();

	public AllUserController() {

	}

	@FXML
	public ResourceBundle resources;

	@FXML
	public void initialize() {
	}

	@FXML
	public Button admin;

	@FXML
	public Button manager;

	@FXML
	public Button cashier;

	@FXML
	public Button accountHolder;

	@FXML
	public Button complainHandler;

	@FXML
	public void goToLogin0(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.allUserToLoginSimple(s);

	}

	@FXML
	public void goToManagerLogin(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.allUserToManager(s);

	}

	@FXML
	public void goToLoginCashier(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.MoveloginCashier(s);

	}

	@FXML
	void goToLoginAccountHolder(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.MoveloginAccountHolder(s);
		
	}
}
