package application;

import java.io.IOException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;

public class MainScreenController {

	boolean check = false;

	Bank m = new Bank();

	int index = 0;

	@FXML
	private Button back;

	@FXML
	private Button logout;

	@FXML
	private Button createAccount;

	@FXML
	private Button balanceView;

	@FXML
	private Button viewAccountDetails;

	@FXML
	private TextField addressUA;

	@FXML
	private Button updateUA;

	@FXML
	private Button searchUA;

	@FXML
	private TextField phoneUA;

	@FXML
	private Label messageIfAccNotFound;

	@FXML
	private Button searchAccount;

	@FXML
	private TextField cnicUA;

	@FXML
	private Label accountFound;

	@FXML
	private Button changePassword;

	@FXML
	private PasswordField newPassword;

	@FXML
	private PasswordField confirmPassword;

	@FXML
	private Label currentPasswordError;

	@FXML
	private Label confirmationMessage;

	@FXML
	private Button savePassword;

	@FXML
	private Label confirmPasswordError;

	@FXML
	private Label newPasswordError;

	@FXML
	private PasswordField currentPassword;

	@FXML
	private Label creationDateVAD;

	@FXML
	private Label accountTypeVAD;

	@FXML
	private Label dateOfBirthVAD;

	@FXML
	private Label accountNumberVAD;

	@FXML
	private Label addressVAD;

	@FXML
	private Button searchVAD;

	@FXML
	private Label genderVAD;

	@FXML
	private Label usernameVAD;

	@FXML
	private TextField cnicVAD;

	@FXML
	private Label messageIfAccNotFoundVAD;

	@FXML
	private Button view;

	// Add Employee TextFields

	@FXML
	private PasswordField EmployeePassword;

	@FXML
	private TextField EmployeeGender;

	@FXML
	private TextField EmployeeCnic;

	@FXML
	private PasswordField EmployeeConfirmPassword;

	@FXML
	private TextField EmployeePhoneNumber;

	@FXML
	private TextField EmployeeAddress;

	@FXML
	private TextField EmployeeName;

	@FXML
	private TextField EmployeeUserName;

	@FXML
	private TextField EmployeeSalary;

	@FXML
	private TextField EmployeeHireDate;

	@FXML
	private Button add;

	@FXML
	private Button addEmployeeCashier;

	@FXML
	private Label ErrorAddCashier;

	@FXML
	private Label EmployeeUserNameError;

	@FXML
	private Label EmployeeConfirmPasswordError;

	@FXML
	private Button show;

	@FXML
	private Button viewTransaction;

	@FXML
	TableView<Transcation> data = new TableView<Transcation>();

	@FXML
	private TableColumn<Transcation, String> accountType;

	@FXML
	private TableColumn<Transcation, Double> amount;

	@FXML
	private TableColumn<Transcation, String> transectionDate;

	@FXML
	private TableColumn<Transcation, String> username;

	@FXML
	private TableColumn<Transcation, String> accountNo;

	@FXML
	private TableColumn<Transcation, String> transaction_Type;

	@FXML
	private Label noDataFoundFortransaction;

	@FXML
	private Label CashierAddedSuccessfully;

	public MainScreenController() {
	}

	@FXML
	public ResourceBundle resources;

	@FXML
	public void initialize() {
	}

	@FXML
	public void start(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.start(s);

	}

	@FXML
	void backToMain(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MainScreen(s);

	}

	@FXML
	public void createAccounts(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.createAccount(s);

	}

	@FXML
	void moveToUpdateAccount(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.updateAccountScreen(s);
	}

	@FXML
	void searchAccount(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.searchAccountScreen(s);
	}

	@FXML
	void changePassword(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.changePasswordScreen(s);
	}

	@FXML
	void viewTransaction(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.viewTransactions(s);
	}

	@FXML
	void moveToViewAccountDetails(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.viewAccountDetails(s);
	}

	@FXML
	void searchVAD(ActionEvent event) {

		String cnic = cnicVAD.getText();

		if (!(cnic.isBlank())) {

			if ((!(cnic.isBlank()))) {

				for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {
					if (DatabaseLedger.getAccounts().get(i).getAccountHolder().getCnic().equals(cnic)) {

						usernameVAD.setText(DatabaseLedger.getAccounts().get(i).getAccountHolder().getUsername());
						accountNumberVAD.setText(DatabaseLedger.getAccounts().get(i).getAccountHolder().getAccountNumber());
						accountTypeVAD.setText(DatabaseLedger.getAccounts().get(i).getAccountHolder().getAccountType());
						genderVAD.setText(DatabaseLedger.getAccounts().get(i).getAccountHolder().getGender());
						dateOfBirthVAD.setText(DatabaseLedger.getAccounts().get(i).getAccountHolder().getDateOfBirth());
						creationDateVAD.setText(DatabaseLedger.getAccounts().get(i).getAccountHolder().getCreationDate());
						addressVAD.setText(DatabaseLedger.getAccounts().get(i).getAccountHolder().getAddress());
						messageIfAccNotFoundVAD.setText("Account Found");
						return;
					}
				}
				messageIfAccNotFoundVAD.setText("No Account exists with CNIC Number: " + cnic);
			}
		} else {
			messageIfAccNotFoundVAD.setText("Please Enter CNIC Number");
		}

	}

	@FXML
	void saveChangePassword(ActionEvent event) {

		String enteredPassword = currentPassword.getText();

		if (!(enteredPassword.isBlank())) {

			if (DatabaseLedger.user.get(0).getPassword().equals(enteredPassword)) {
				currentPasswordError.setText("Password matched.");

				if ((!(newPassword.getText().isBlank())) && (!(confirmPassword.getText().isBlank()))) {

					if (newPassword.getText().equals(confirmPassword.getText())) {

						DatabaseLedger.user.get(0).setPassword(newPassword.getText());
						confirmationMessage.setText("Password changed successfully.");

						confirmPasswordError.setText(" ");

					} else {
						confirmPasswordError.setText("password doesn't match.");
					}
				}

				else if ((newPassword.getText().isBlank()) && (!(confirmPassword.getText().isBlank()))) {
					newPasswordError.setText("Please enter new password first.");
				}

				else if ((!(newPassword.getText().isBlank())) && (confirmPassword.getText().isBlank())) {
					confirmPasswordError.setText("Please confirm password first.");
				} else {
					newPasswordError.setText("Please enter new password first.");
					confirmPasswordError.setText("Please confirm password first.");
				}

			} else {
				currentPasswordError.setText("Wrong password.");
			}
		} else {
			currentPasswordError.setText("Please enter password first.");
		}
	}

	@FXML
	void searchOnly(ActionEvent event) {
		index = 0;
		String cnic = cnicUA.getText();

		if ((!(cnic.isBlank()))) {

			for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {
				if (DatabaseLedger.getAccounts().get(i).getAccountHolder().getCnic().equals(cnic)) {

					accountFound.setText("Account Found.");
					return;
				}
			}
			messageIfAccNotFound.setText("No Account exists with CNIC Number: " + cnic);
		} else {
			messageIfAccNotFound.setText("Please Enter CNIC Number");
		}

	}

	@FXML
	void search(ActionEvent event) {
		index = 0;
		String cnic = cnicUA.getText();

		if (!(cnic.isBlank())) {

			if ((!(cnic.isBlank()))) {

				for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {
					if (DatabaseLedger.getAccounts().get(i).getAccountHolder().getCnic().equals(cnic)) {

						accountFound.setText("Account Found, Update Fileds");
						index = i;
						return;

					}

				}
				messageIfAccNotFound.setText("No Account exists with CNIC Number: " + cnic);
			}
		} else {
			messageIfAccNotFound.setText("Please Enter CNIC Number");
		}
	}

	@FXML
	void update(ActionEvent event) {

		if ((!(phoneUA.getText().isBlank()) && (!(addressUA.getText().isBlank())))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setPhoneNo(phoneUA.getText());
			DatabaseLedger.getAccounts().get(index).getAccountHolder().setAddress(addressUA.getText());

		}

		else if ((phoneUA.getText().isBlank() && (!(addressUA.getText().isBlank())))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setAddress(addressUA.getText());

			Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
			m.start(s);

		}

		else if ((!(phoneUA.getText().isBlank()) && (addressUA.getText().isBlank()))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setPhoneNo(phoneUA.getText());

			Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
			m.start(s);

		}
	}

	@FXML
	void addEmployee(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.addCashier(s);
	}

	@FXML
	void addCashier(ActionEvent event) {

		if (!(EmployeeName.getText().isBlank()) && (!(EmployeeUserName.getText().isBlank()))
				&& (!(EmployeePassword.getText().isBlank())) && (!(EmployeeConfirmPassword.getText().isBlank()))
				&& (!(EmployeePhoneNumber.getText().isBlank())) && (!(EmployeeCnic.getText().isBlank()))
				&& (!(EmployeeGender.getText().isBlank())) && (!(EmployeeSalary.getText().isBlank()))
				&& (!(EmployeeHireDate.getText().isBlank())) && (!(EmployeeAddress.getText().isBlank()))) {

			if (EmployeePassword.getText().equals(EmployeeConfirmPassword.getText())) {

				double salary = Double.parseDouble(EmployeeSalary.getText());

				Cashier c = new Cashier(EmployeeName.getText(), EmployeePassword.getText(), EmployeeGender.getText(),
						EmployeeAddress.getText(), EmployeeCnic.getText(), EmployeePhoneNumber.getText(), salary,
						EmployeeHireDate.getText(), EmployeeUserName.getText());

				if (DatabaseLedger.getCashier().isEmpty()) {
					DatabaseLedger.cashier.add(c);
					CashierAddedSuccessfully.setText("Cashier added successfully.");
				}

				else {

					boolean check = false;

					for (int i = 0; i < DatabaseLedger.cashier.size(); i++) {
						if (DatabaseLedger.getCashier().get(i).getUsername().equals(EmployeeUserName.getText())) {

							check = true;
							break;
						}
					}

					if (check == true) {
						EmployeeUserNameError.setText("Username is not unique.");
					} else {
						DatabaseLedger.getCashier().add(c);
					}
				}

			} else {
				EmployeeConfirmPasswordError.setText("Password doesn't match.");
			}

		} else {
			ErrorAddCashier.setText("Please fill out all fields.");
		}

	}

	// view Transaction

	public void addtableViewData() {

		if (check == false) {

			accountType = new TableColumn<Transcation, String>("   Account Type   ");
			amount = new TableColumn<Transcation, Double>("Transected Account");
			username = new TableColumn<Transcation, String>("     Username     ");
			transectionDate = new TableColumn<Transcation, String>(" Transection Date ");
			accountNo = new TableColumn<Transcation, String>("  Account Number  ");
			transaction_Type = new TableColumn<Transcation, String>(" Transaction Type ");

			accountNo.setCellValueFactory(new PropertyValueFactory<Transcation, String>("accountNumber"));
			accountNo.setCellFactory(TextFieldTableCell.forTableColumn());
			username.setCellValueFactory(new PropertyValueFactory<Transcation, String>("customerName"));
			username.setCellFactory(TextFieldTableCell.forTableColumn());
			accountType.setCellValueFactory(new PropertyValueFactory<Transcation, String>("accountType"));
			accountType.setCellFactory(TextFieldTableCell.forTableColumn());
			transaction_Type.setCellValueFactory(new PropertyValueFactory<Transcation, String>("transcationType"));
			transaction_Type.setCellFactory(TextFieldTableCell.forTableColumn());
			amount.setCellValueFactory(new PropertyValueFactory<Transcation, Double>("amount"));
			amount.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
			transectionDate.setCellValueFactory(new PropertyValueFactory<Transcation, String>("date"));
			transectionDate.setCellFactory(TextFieldTableCell.forTableColumn());

			data.getColumns().add(accountNo);
			data.getColumns().add(username);
			data.getColumns().add(accountType);
			data.getColumns().add(transaction_Type);
			data.getColumns().add(amount);
			data.getColumns().add(transectionDate);

			accountNo.prefWidthProperty().bind(data.widthProperty().multiply(0.15));
			username.prefWidthProperty().bind(data.widthProperty().multiply(0.15));
			accountType.prefWidthProperty().bind(data.widthProperty().multiply(0.16));
			transaction_Type.prefWidthProperty().bind(data.widthProperty().multiply(0.17));
			amount.prefWidthProperty().bind(data.widthProperty().multiply(0.17));
			transectionDate.prefWidthProperty().bind(data.widthProperty().multiply(0.2));

			transectionDate.setResizable(false);
			amount.setResizable(false);
			transaction_Type.setResizable(false);
			accountType.setResizable(false);
			username.setResizable(false);
			accountNo.setResizable(false);

			check = true;
		}

		if (DatabaseLedger.transcation.isEmpty()) {
			noDataFoundFortransaction.setText("No record found to display.");
		} else {

			for (int i = 0; i < DatabaseLedger.transcation.size(); i++) {

				data.getItems().add(new Transcation(DatabaseLedger.transcation.get(i).getCustomerName(),
						DatabaseLedger.transcation.get(i).getAccountNumber(), DatabaseLedger.transcation.get(i).getAccountType(),
						DatabaseLedger.transcation.get(i).getTranscationType(), DatabaseLedger.transcation.get(i).getDate(),
						DatabaseLedger.transcation.get(i).getAmount()));
			}
		}

	}

}