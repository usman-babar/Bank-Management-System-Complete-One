package application;

import java.io.IOException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignUpController {

	Bank m = new Bank();
	User accountHolder;

	@FXML
	private Button cancel;

	@FXML
	private PasswordField password;

	@FXML
	private Label fillForm;

	@FXML
	private TextField gender;

	@FXML
	private TextField phone;

	@FXML
	private TextField dob;

	@FXML
	private TextField accountNo;

	@FXML
	private TextField name;

	@FXML
	private TextField cnic;

	@FXML
	private TextField creationDate;

	@FXML
	private Button signUp;

	@FXML
	private TextField username;

	@FXML
	private TextField AccountType;

	@FXML
	private TextField address;

	@FXML
	private Label AccountNoError;

	@FXML
	private Label accountTypeError;

	@FXML
	private Label cnicExist;

	@FXML
	private Label phoneNumberError;

	@FXML
	private Label genderError;

	@FXML
	private Label userNmaeExist;

	@FXML
	private TextField accountType;

	public SignUpController() {

	}

	@FXML
	public ResourceBundle resources;

	@FXML
	public void initialize() {
	}

	// in case of cancel
	@FXML
	public void backToMain(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.MainScreen(s);

	}

	// in case of sign up
	@FXML
	public void backToMainAfterSignUp(ActionEvent event) throws IOException {

		String nameAH = name.getText();
		String passWord = password.getText();
		String phoneAH = phone.getText();
		String addressAH = address.getText();
		String cnicAH = cnic.getText();
		String usernameAH = username.getText();
		String sex = gender.getText();
		String birthDate = dob.getText();
		String accountNum = accountNo.getText();
		String AccountType = accountType.getText();
		String dateCreation = creationDate.getText();

		accountHolder = new AccountHolder(nameAH, passWord, phoneAH, addressAH, cnicAH, usernameAH, sex, birthDate,
				accountNum, AccountType, dateCreation);

		if ((!(nameAH.isBlank())) && (!(usernameAH.isBlank())) && (!(phoneAH.isBlank())) && (!(passWord.isBlank()))
				&& (!(cnicAH.isBlank())) && (!(sex.isBlank())) && (!(birthDate.isBlank())) && (!(accountNum.isBlank()))
				&& (!(dateCreation.isBlank())) && (!(AccountType.isBlank())) && (!(addressAH.isBlank()))
				&& (!(dateCreation.isBlank()))) {

			int result = m.newUserRecordCheck();

			if (result == 0) {

				if (usernameAH.length() > 6) {

					Boolean flag = false;

					if (phoneAH.length() == 11) {

						for (int i = 0; i < phoneAH.length(); i++) {

							if (!Character.isDigit(phoneAH.charAt(i))) {
								flag = true;
							}
						}

						if (flag == false) {

							if (accountNum.length() == 4) {

								boolean aNoCheck = false;

								for (int i = 0; i < accountNum.length(); i++) {

									if (!Character.isDigit(accountNum.charAt(i))) {
										aNoCheck = true;
									}
								}

								if (aNoCheck == false) {

									boolean cnicCheck = false;

									for (int i = 0; i < cnicAH.length(); i++) {

										if (!Character.isDigit(cnicAH.charAt(i))) {
											cnicCheck = true;
										}
									}

									if (cnicCheck == false) {

										if (sex.equalsIgnoreCase("male") || sex.equalsIgnoreCase("female")
												|| sex.equalsIgnoreCase("other")) {

											if (AccountType.equalsIgnoreCase("Saving")) {
												m.newUserAdd(accountNum, dateCreation, (AccountHolder) accountHolder,
														AccountType);
											}

											else if (AccountType.equalsIgnoreCase("checking")) {
												m.newUserAdd(accountNum, dateCreation, (AccountHolder) accountHolder,
														AccountType);
											}

											else {
												// enter field under accountType
												accountTypeError.setText("Saving or Checking");
												genderError.setText("");
												cnicExist.setText("");
												AccountNoError.setText("");
												phoneNumberError.setText("");
												userNmaeExist.setText("");
												System.out.println("Can only be saving/checking account");
												return;
											}

										}

										else {
											genderError.setText("male, female, other only");
											cnicExist.setText("");
											AccountNoError.setText("");
											phoneNumberError.setText("");
											accountTypeError.setText("");
											userNmaeExist.setText("");
											return;
										}

									} else {
										cnicExist.setText("Only Digits");
										AccountNoError.setText("");
										phoneNumberError.setText("");
										accountTypeError.setText("");
										genderError.setText("");
										userNmaeExist.setText("");
										return;
									}

								}

								else {
									AccountNoError.setText("Only contain digits");
									phoneNumberError.setText("");
									accountTypeError.setText("");
									cnicExist.setText("");
									genderError.setText("");
									userNmaeExist.setText("");
									return;
								}

							} else {
								AccountNoError.setText("must be eof 4 digits");
								accountTypeError.setText("");
								phoneNumberError.setText("");
								cnicExist.setText("");
								genderError.setText("");
								userNmaeExist.setText("");
								return;
							}

						} else {
							phoneNumberError.setText("Phone Number doesn't contain character");
							AccountNoError.setText("");
							cnicExist.setText("");
							genderError.setText("");
							userNmaeExist.setText("");
							accountTypeError.setText("");
							return;
						}

					} else {
						phoneNumberError.setText("should be of 11 digits");
						userNmaeExist.setText("");
						accountTypeError.setText("");
						AccountNoError.setText("");
						cnicExist.setText("");
						genderError.setText("");
						return;
					}

				} else {
					userNmaeExist.setText("Atleast 6 character");
					phoneNumberError.setText("");
					accountTypeError.setText("");
					AccountNoError.setText("");
					cnicExist.setText("");
					genderError.setText("");
					return;
				}

			}

			else {

				int check = m.userAdd(accountNum, cnicAH, usernameAH);

				if (check == 0) {
					AccountNoError.setText("Account number already exists.");
					cnicExist.setText(" ");
					userNmaeExist.setText(" ");
					accountTypeError.setText("");
					return;
				} else if (check == 1) {
					cnicExist.setText("CNIC Number already exists.");
					userNmaeExist.setText(" ");
					AccountNoError.setText(" ");
					accountTypeError.setText("");
					return;
				} else if (check == 2) {
					userNmaeExist.setText("Username already exists.");
					cnicExist.setText(" ");
					AccountNoError.setText(" ");
					accountTypeError.setText("");
					return;
				} else {

					if (usernameAH.length() > 6) {

						Boolean flag = false;

						if (phoneAH.length() == 11) {

							for (int i = 0; i < phoneAH.length(); i++) {

								if (!Character.isDigit(phoneAH.charAt(i))) {
									flag = true;
								}
							}

							if (flag == false) {

								if (accountNum.length() == 4) {

									boolean aNoCheck = false;

									for (int i = 0; i < accountNum.length(); i++) {

										if (!Character.isDigit(accountNum.charAt(i))) {
											aNoCheck = true;
										}
									}

									if (aNoCheck == false) {

										boolean cnicCheck = false;

										for (int i = 0; i < cnicAH.length(); i++) {

											if (!Character.isDigit(cnicAH.charAt(i))) {
												cnicCheck = true;
											}
										}

										if (cnicCheck == false) {

											if (sex.equalsIgnoreCase("male") || sex.equalsIgnoreCase("female")
													|| sex.equalsIgnoreCase("other")) {

												if (AccountType.equalsIgnoreCase("saving")) {
													m.newUserAdd(accountNum, dateCreation,
															(AccountHolder) accountHolder, AccountType);
												}

												else if (AccountType.equalsIgnoreCase("checking")) {
													m.newUserAdd(accountNum, dateCreation,
															(AccountHolder) accountHolder, AccountType);
												}

												else {
													// enter field under accountType
													accountTypeError.setText("Saving or Checking");
													genderError.setText("");
													cnicExist.setText("");
													AccountNoError.setText("");
													phoneNumberError.setText("");
													userNmaeExist.setText("");
													System.out.println("Can only be saving/checking account");
													return;
												}

											}

											else {
												genderError.setText("male, female, other only");
												cnicExist.setText("");
												AccountNoError.setText("");
												phoneNumberError.setText("");
												accountTypeError.setText("");
												userNmaeExist.setText("");
												return;
											}

										} else {
											cnicExist.setText("Only Digits");
											AccountNoError.setText("");
											phoneNumberError.setText("");
											accountTypeError.setText("");
											genderError.setText("");
											userNmaeExist.setText("");
											return;
										}

									}

									else {
										AccountNoError.setText("Only contain digits");
										phoneNumberError.setText("");
										accountTypeError.setText("");
										cnicExist.setText("");
										genderError.setText("");
										userNmaeExist.setText("");
										return;
									}

								} else {
									AccountNoError.setText("must be eof 4 digits");
									accountTypeError.setText("");
									phoneNumberError.setText("");
									cnicExist.setText("");
									genderError.setText("");
									userNmaeExist.setText("");
									return;
								}

							} else {
								phoneNumberError.setText("Phone Number doesn't contain character");
								AccountNoError.setText("");
								cnicExist.setText("");
								genderError.setText("");
								userNmaeExist.setText("");
								accountTypeError.setText("");
								return;
							}

						} else {
							phoneNumberError.setText("should be of 11 digits");
							userNmaeExist.setText("");
							accountTypeError.setText("");
							AccountNoError.setText("");
							cnicExist.setText("");
							genderError.setText("");
							return;
						}

					} else {
						userNmaeExist.setText("Atleast 6 character");
						phoneNumberError.setText("");
						accountTypeError.setText("");
						AccountNoError.setText("");
						cnicExist.setText("");
						genderError.setText("");
						return;
					}
				}
			}

			// after account is created
			Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

			m.MainScreen(s);
		} else {
			fillForm.setText("Kindly fill out all fields.");
			return;
		}
	}

	@FXML
	public void backToManagerMainAfterSignUp(ActionEvent event) throws IOException {

		String nameAH = name.getText();
		String passWord = password.getText();
		String phoneAH = phone.getText();
		String addressAH = address.getText();
		String cnicAH = cnic.getText();
		String usernameAH = username.getText();
		String sex = gender.getText();
		String birthDate = dob.getText();
		String accountNum = accountNo.getText();
		String account_Type = AccountType.getText();
		String dateCreation = creationDate.getText();

		accountHolder = new AccountHolder(nameAH, passWord, phoneAH, addressAH, cnicAH, usernameAH, sex, birthDate,
				accountNum, account_Type, dateCreation);

		if ((!(nameAH.isBlank())) && (!(usernameAH.isBlank())) && (!(phoneAH.isBlank())) && (!(passWord.isBlank()))
				&& (!(cnicAH.isBlank())) && (!(sex.isBlank())) && (!(birthDate.isBlank())) && (!(accountNum.isBlank()))
				&& (!(dateCreation.isBlank())) && (!(account_Type.isBlank())) && (!(addressAH.isBlank()))
				&& (!(dateCreation.isBlank()))) {

			int result = m.newUserRecordCheck();

			if (result == 0) {

				if (usernameAH.length() > 6) {

					Boolean flag = false;

					if (phoneAH.length() == 11) {

						for (int i = 0; i < phoneAH.length(); i++) {

							if (!Character.isDigit(phoneAH.charAt(i))) {
								flag = true;
							}
						}

						if (flag == false) {

							if (accountNum.length() == 4) {

								boolean aNoCheck = false;

								for (int i = 0; i < accountNum.length(); i++) {

									if (!Character.isDigit(accountNum.charAt(i))) {
										aNoCheck = true;
									}
								}

								if (aNoCheck == false) {

									boolean cnicCheck = false;

									for (int i = 0; i < cnicAH.length(); i++) {

										if (!Character.isDigit(cnicAH.charAt(i))) {
											cnicCheck = true;
										}
									}

									if (cnicCheck == false) {

										if (sex.equalsIgnoreCase("male") || sex.equalsIgnoreCase("female")
												|| sex.equalsIgnoreCase("other")) {

											if (account_Type.equalsIgnoreCase("Saving")) {
												m.newUserAdd(accountNum, dateCreation, (AccountHolder) accountHolder,
														account_Type);
											}

											else if (account_Type.equalsIgnoreCase("checking")) {
												m.newUserAdd(accountNum, dateCreation, (AccountHolder) accountHolder,
														account_Type);
											}

											else {
												// enter field under accountType
												accountTypeError.setText("Saving or Checking");
												genderError.setText("");
												cnicExist.setText("");
												AccountNoError.setText("");
												phoneNumberError.setText("");
												userNmaeExist.setText("");
												System.out.println("Can only be saving/checking account");
												return;
											}

										}

										else {
											genderError.setText("male, female, other only");
											cnicExist.setText("");
											AccountNoError.setText("");
											phoneNumberError.setText("");
											accountTypeError.setText("");
											userNmaeExist.setText("");
											return;
										}

									} else {
										cnicExist.setText("Only Digits");
										AccountNoError.setText("");
										phoneNumberError.setText("");
										accountTypeError.setText("");
										genderError.setText("");
										userNmaeExist.setText("");
										return;
									}

								}

								else {
									AccountNoError.setText("Only contain digits");
									phoneNumberError.setText("");
									accountTypeError.setText("");
									cnicExist.setText("");
									genderError.setText("");
									userNmaeExist.setText("");
									return;
								}

							} else {
								AccountNoError.setText("must be eof 4 digits");
								accountTypeError.setText("");
								phoneNumberError.setText("");
								cnicExist.setText("");
								genderError.setText("");
								userNmaeExist.setText("");
								return;
							}

						} else {
							phoneNumberError.setText("Phone Number doesn't contain character");
							AccountNoError.setText("");
							cnicExist.setText("");
							genderError.setText("");
							userNmaeExist.setText("");
							accountTypeError.setText("");
							return;
						}

					} else {
						phoneNumberError.setText("should be of 11 digits");
						userNmaeExist.setText("");
						accountTypeError.setText("");
						AccountNoError.setText("");
						cnicExist.setText("");
						genderError.setText("");
						return;
					}

				} else {
					userNmaeExist.setText("Atleast 6 character");
					phoneNumberError.setText("");
					accountTypeError.setText("");
					AccountNoError.setText("");
					cnicExist.setText("");
					genderError.setText("");
					return;
				}

			}

			else {

				int check = m.userAdd(accountNum, cnicAH, usernameAH);

				if (check == 0) {
					AccountNoError.setText("Account number already exists.");
					cnicExist.setText(" ");
					userNmaeExist.setText(" ");
					accountTypeError.setText("");
					return;
				} else if (check == 1) {
					cnicExist.setText("CNIC Number already exists.");
					userNmaeExist.setText(" ");
					AccountNoError.setText(" ");
					accountTypeError.setText("");
					return;
				} else if (check == 2) {
					userNmaeExist.setText("Username already exists.");
					cnicExist.setText(" ");
					AccountNoError.setText(" ");
					accountTypeError.setText("");
					return;
				} else {

					if (usernameAH.length() > 6) {

						Boolean flag = false;

						if (phoneAH.length() == 11) {

							for (int i = 0; i < phoneAH.length(); i++) {

								if (!Character.isDigit(phoneAH.charAt(i))) {
									flag = true;
								}
							}

							if (flag == false) {

								if (accountNum.length() == 4) {

									boolean aNoCheck = false;

									for (int i = 0; i < accountNum.length(); i++) {

										if (!Character.isDigit(accountNum.charAt(i))) {
											aNoCheck = true;
										}
									}

									if (aNoCheck == false) {

										boolean cnicCheck = false;

										for (int i = 0; i < cnicAH.length(); i++) {

											if (!Character.isDigit(cnicAH.charAt(i))) {
												cnicCheck = true;
											}
										}

										if (cnicCheck == false) {

											if (sex.equalsIgnoreCase("male") || sex.equalsIgnoreCase("female")
													|| sex.equalsIgnoreCase("other")) {

												if (account_Type.equalsIgnoreCase("Saving")) {
													m.newUserAdd(accountNum, dateCreation,
															(AccountHolder) accountHolder, account_Type);
												}

												else if (account_Type.equalsIgnoreCase("checking")) {
													m.newUserAdd(accountNum, dateCreation,
															(AccountHolder) accountHolder, account_Type);
												}

												else {
													// enter field under accountType
													accountTypeError.setText("Saving or Checking");
													genderError.setText("");
													cnicExist.setText("");
													AccountNoError.setText("");
													phoneNumberError.setText("");
													userNmaeExist.setText("");
													System.out.println("Can only be saving/checking account");
													return;
												}

											}

											else {
												genderError.setText("male, female, other only");
												cnicExist.setText("");
												AccountNoError.setText("");
												phoneNumberError.setText("");
												accountTypeError.setText("");
												userNmaeExist.setText("");
												return;
											}

										} else {
											cnicExist.setText("Only Digits");
											AccountNoError.setText("");
											phoneNumberError.setText("");
											accountTypeError.setText("");
											genderError.setText("");
											userNmaeExist.setText("");
											return;
										}

									}

									else {
										AccountNoError.setText("Only contain digits");
										phoneNumberError.setText("");
										accountTypeError.setText("");
										cnicExist.setText("");
										genderError.setText("");
										userNmaeExist.setText("");
										return;
									}

								} else {
									AccountNoError.setText("must be eof 4 digits");
									accountTypeError.setText("");
									phoneNumberError.setText("");
									cnicExist.setText("");
									genderError.setText("");
									userNmaeExist.setText("");
									return;
								}

							} else {
								phoneNumberError.setText("Phone Number doesn't contain character");
								AccountNoError.setText("");
								cnicExist.setText("");
								genderError.setText("");
								userNmaeExist.setText("");
								accountTypeError.setText("");
								return;
							}

						} else {
							phoneNumberError.setText("should be of 11 digits");
							userNmaeExist.setText("");
							accountTypeError.setText("");
							AccountNoError.setText("");
							cnicExist.setText("");
							genderError.setText("");
							return;
						}

					} else {
						userNmaeExist.setText("Atleast 6 character");
						phoneNumberError.setText("");
						accountTypeError.setText("");
						AccountNoError.setText("");
						cnicExist.setText("");
						genderError.setText("");
						return;
					}

				}

			}
			// after account is created
			Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

			m.MainScreenManager(s);
		} else {
			fillForm.setText("Kindly fill out all fields.");
			return;
		}
	}

	@FXML
	public void backToManagerMain(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.MainScreenManager(s);

	}

}
