package application;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SavingAccount extends Account {

	double previousTranscation;
	String dateTime = null;
	SimpleDateFormat sdf;
	Date transcationDate;

	public SavingAccount() {
		super();
	}

	public SavingAccount(String accountNumber, String creationDate, AccountHolder accountHolder) {
		super(accountNumber, creationDate, accountHolder);
	}

	@Override
	public int makeDeposit(double amount) {
		this.sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		this.transcationDate = new Date();
		if (amount > 0) {
			setBalance(getBalance() + amount);
			previousTranscation = amount;
			this.dateTime = sdf.format(transcationDate);
			DatabaseLedger.getTranscation()
					.add(new Transcation(getAccountHolder().getUsername(), getAccountHolder().getAccountNumber(),
							getAccountHolder().getAccountType(), "Deposit", this.dateTime, amount));
			return 1;
		}
		return -1;
	}

	@Override
	public int makeWithDrawal(double amount) {
		this.sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		this.transcationDate = new Date();
		if (amount > 0) {
			if (amount <= balance) {
				setBalance(getBalance() - amount);
				previousTranscation = -amount;
				this.dateTime = sdf.format(transcationDate);
				DatabaseLedger.getTranscation()
						.add(new Transcation(getAccountHolder().getUsername(), getAccountHolder().getAccountNumber(),
								getAccountHolder().getAccountType(), "Withdraw", this.dateTime, amount));
				
				return 1;
			} else {
				return -2;
			}
		}
		return -1;
	}

	@Override
	public int transferAmount(double amount, Account account) {
		this.sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		this.transcationDate = new Date();
		if (this.balance >= amount) {
			this.setBalance(this.getBalance() - amount);
			account.setBalance(account.getBalance() + amount);
			previousTranscation = -amount;
			this.dateTime = sdf.format(transcationDate);
			
			DatabaseLedger.getTranscation()
					.add(new Transcation(this.getAccountHolder().getUsername(), this.getAccountHolder().getAccountNumber(),
							this.getAccountHolder().getAccountType(),"Transfer",  this.dateTime, amount,
							account.getAccountHolder().getName(), account.getAccountHolder().getAccountNumber(),
							account.getAccountHolder().getAccountType()));
			return 1;
		}
		return -1;
	}

}
