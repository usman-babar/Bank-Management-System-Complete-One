package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class WithdrawController {

	Bank m = new Bank();
	static int searchIndex = -1;

	@FXML
	private Button Withdraw;

	@FXML
	private Label accountNumber;

	@FXML
	private Label accountType;

	@FXML
	private Button back;

	@FXML
	private Label currentBalance;

	@FXML
	private TextField withdrawAmount;

	@FXML
	private Label messageAfterWithdraw;

	@FXML
	private Label messageIfAccNotFound;

	@FXML
	private Button search;

	@FXML
	private TextField throughAccountNumber;

	@FXML
	private TextField throughCNICNumber;

	@FXML
	void WithdrawAmount(ActionEvent event) throws IOException {

		double amount = Double.parseDouble(withdrawAmount.getText());

		if (searchIndex >= 0) {
			int wValue = m.withdraw(amount, searchIndex);

			if (wValue == 1) {
				messageAfterWithdraw.setText("Amount is withdrawn successfully!");
			} else if (wValue == -1) {
				messageAfterWithdraw.setText("Amount can't be negative!!");
			} else if (wValue == -2) {
				messageAfterWithdraw.setText("Withdraw Amount is greater than current Balance");
			} else if (wValue == -3) {
				messageAfterWithdraw.setText("Amount is greater than 10,000");
			}
		}
	}

	@FXML
	void WithdrawSearch(ActionEvent event) throws IOException {

		String accountNum = throughAccountNumber.getText();
		String cnic = throughCNICNumber.getText();
		searchIndex = -1;
		try {

			if ((!(accountNum.isBlank()) && cnic.isBlank()) || (!(cnic.isBlank()) && accountNum.isBlank())) {

				if ((!(accountNum.isBlank()))) {

					Account a = m.withdraw(accountNum, cnic);

					if (a != null) {
						accountNumber.setText(a.getAccountNumber());
						accountType.setText(a.getAccountHolder().getAccountType());
						currentBalance.setText(String.valueOf(a.getBalance()));

						messageIfAccNotFound.setText(" ");

						return;
					}
				}

				else if ((!(cnic.isBlank()))) {

					Account a = m.withdraw(accountNum, cnic);

					if (a != null) {
						accountNumber.setText(a.getAccountNumber());
						accountType.setText(a.getAccountHolder().getAccountType());
						currentBalance.setText(String.valueOf(a.getBalance()));

						messageIfAccNotFound.setText(" ");
						return;
					}
				}
			} else {
				messageIfAccNotFound.setText("Please!! Search through Account Number or CNIC Number");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			if (searchIndex == -1)
				messageIfAccNotFound.setText("No Account exists");
		}
	}

	@FXML
	void goToCashierMainScreen(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.MainScreenCashier(s);
	}

}
