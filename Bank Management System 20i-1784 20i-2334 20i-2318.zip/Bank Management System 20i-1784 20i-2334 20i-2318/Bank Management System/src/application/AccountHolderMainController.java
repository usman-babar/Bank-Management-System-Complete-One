package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;

public class AccountHolderMainController {

	Bank m = new Bank();

	boolean check = false;

	@FXML
	private Button userInfo;

	@FXML
	private Button logout;

	@FXML
	private Label welcome;

	@FXML
	private Label balance;

	@FXML
	private Button checkBalance;

	@FXML
	private Label accountFound;

	@FXML
	private Button viewTransection;

	@FXML
	private Button show;

	@FXML
	private Button back;

	@FXML
	private Label userInfoBalance;

	@FXML
	private Label userInfoCNIC;

	@FXML
	private Label userInfoPhoneNumber;

	@FXML
	private Label userInfoName;

	@FXML
	private Label userInfoAddress;

	@FXML
	private Label userInfoUserName;

	@FXML
	private Label userInfoGender;

	@FXML
	private Label userInfoAccounttype;
	
	@FXML
	private Label ErrorTransaction;
	

	@FXML
	TableView<Transcation> data = new TableView<Transcation>();

	@FXML
	private TableColumn<Transcation, String> accountType;

	@FXML
	private TableColumn<Transcation, Double> amount;

	@FXML
	private TableColumn<Transcation, String> transectionDate;

	@FXML
	private TableColumn<Transcation, String> username;

	@FXML
	private TableColumn<Transcation, String> accountNo;

	@FXML
	private TableColumn<Transcation, String> transaction_Type;
	
	

	@FXML
	public void start(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.start(s);

	}

	@FXML
	void backToMain(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MainScreenAccountHolder(s);

	}

	@FXML
	public void checkBalance(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MoveToCheckBalance(s);

	}

	@FXML
	void viewTransection(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MoveToTransection(s);

	}

	@FXML
	void userInfo(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MoveToUserInfo(s);

	}

	public void addtableViewData() throws IOException {

		if (check == false) {

			accountType = new TableColumn<Transcation, String>("   Account Type   ");
			amount = new TableColumn<Transcation, Double>("Transected Account");
			username = new TableColumn<Transcation, String>("     Username     ");
			transectionDate = new TableColumn<Transcation, String>(" Transection Date ");
			accountNo = new TableColumn<Transcation, String>("  Account Number  ");
			transaction_Type = new TableColumn<Transcation, String>(" Transaction Type ");

			accountNo.setCellValueFactory(new PropertyValueFactory<Transcation, String>("accountNumber"));
			accountNo.setCellFactory(TextFieldTableCell.forTableColumn());
			username.setCellValueFactory(new PropertyValueFactory<Transcation, String>("customerName"));
			username.setCellFactory(TextFieldTableCell.forTableColumn());
			accountType.setCellValueFactory(new PropertyValueFactory<Transcation, String>("accountType"));
			accountType.setCellFactory(TextFieldTableCell.forTableColumn());
			transaction_Type.setCellValueFactory(new PropertyValueFactory<Transcation, String>("transcationType"));
			transaction_Type.setCellFactory(TextFieldTableCell.forTableColumn());
			amount.setCellValueFactory(new PropertyValueFactory<Transcation, Double>("amount"));
			amount.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
			transectionDate.setCellValueFactory(new PropertyValueFactory<Transcation, String>("date"));
			transectionDate.setCellFactory(TextFieldTableCell.forTableColumn());

			data.getColumns().add(accountNo);
			data.getColumns().add(username);
			data.getColumns().add(accountType);
			data.getColumns().add(transaction_Type);
			data.getColumns().add(amount);
			data.getColumns().add(transectionDate);

			accountNo.prefWidthProperty().bind(data.widthProperty().multiply(0.15));
			username.prefWidthProperty().bind(data.widthProperty().multiply(0.15));
			accountType.prefWidthProperty().bind(data.widthProperty().multiply(0.16));
			transaction_Type.prefWidthProperty().bind(data.widthProperty().multiply(0.17));
			amount.prefWidthProperty().bind(data.widthProperty().multiply(0.17));
			transectionDate.prefWidthProperty().bind(data.widthProperty().multiply(0.2));

			transectionDate.setResizable(false);
			amount.setResizable(false);
			transaction_Type.setResizable(false);
			accountType.setResizable(false);
			username.setResizable(false);
			accountNo.setResizable(false);

			check = true;
		}

		int check_ = m.transactionAH(data);
		
		
		if(check_ == 0) 
		{
			ErrorTransaction.setText("no record found.");
		}
		
	}

	public void setUserInfo() throws IOException {

		Account a = m.info();

		userInfoAccounttype.setText(a.getAccountHolder().getAccountType());
		userInfoBalance.setText(a.getBalance() + "");
		userInfoCNIC.setText(a.getAccountHolder().getCnic());
		userInfoPhoneNumber.setText(a.getAccountHolder().getPhoneNo());
		userInfoName.setText(a.getAccountHolder().getName());
		userInfoAddress.setText(a.getAccountHolder().getAddress());
		userInfoUserName.setText(a.getAccountHolder().getUsername());
		userInfoGender.setText(a.getAccountHolder().getGender());

	}

	public void showBalance() throws IOException {

		int userIndex = LoginAccountHolder.index;
		
		String amount = m.Balance(userIndex);

		balance.setText(amount);

	}
	
}
