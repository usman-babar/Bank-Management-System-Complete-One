	package application;

import java.util.ArrayList;

public class DatabaseLedger {

	static ArrayList<Account> accounts = new ArrayList<Account>();
	static ArrayList<Transcation> transcation = new ArrayList<>();
	static ArrayList<Cashier> cashier = new ArrayList<>();
	static ArrayList<User> user = new ArrayList<User>();
	

	public static ArrayList<User> getUser() {
		return user;
	}

	public static void setUser(ArrayList<User> user) {
		DatabaseLedger.user = user;
	}

	public static ArrayList<Cashier> getCashier() {
		return cashier;
	}

	public static void setCashier(ArrayList<Cashier> cashier) {
		DatabaseLedger.cashier = cashier;
	}

	public static ArrayList<Account> getAccounts() {
		return accounts;
	}

	public static void setAccounts(ArrayList<Account> accounts) {
		DatabaseLedger.accounts = accounts;
	}

	public static ArrayList<Transcation> getTranscation() {
		return transcation;
	}

	public static void setTranscation(ArrayList<Transcation> transcation) {
		DatabaseLedger.transcation = transcation;
	}

}
