package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class Bank extends Application {

	String fxmlPath = "C:\\Users\\Nexgen\\Desktop\\Java\\UsmanBank\\FXML\\";
	String imagePath = "C:\\Users\\Nexgen\\Desktop\\Java\\UsmanBank\\Data\\User\\";

	String file = "C:\\Users\\Nexgen\\Desktop\\Java\\UsmanBank\\Data\\USERS.txt";

	String accountHolder = imagePath + "AccountHolder.png";
	String cashier = imagePath + "cashier.png";
	String manager = imagePath + "manager.png";
	String owner = imagePath + "owner.png";
	String it = imagePath + "it.png";

	FXMLLoader loader = new FXMLLoader();
	Transcation t = new Transcation();
	Admin admin = new Admin();
	Account account = new Account() {

		@Override
		public int transferAmount(double amount, Account account) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int makeWithDrawal(double amount) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int makeDeposit(double amount) {
			// TODO Auto-generated method stub
			return 0;
		}
	};

	// display all users
	public void start(Stage primaryStage) {
		try {

			String fxmlDocPath = fxmlPath + "Admin//AllUser.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane root = (AnchorPane) loader.load(fxmlStream);

			// Adding image on Screen

			// bank Image
			FileInputStream input = new FileInputStream(it);
			// owner Image
			FileInputStream input1 = new FileInputStream(owner);
			// Manager Image
			FileInputStream input2 = new FileInputStream(manager);
			// Cashier Image
			FileInputStream input3 = new FileInputStream(cashier);
			// AccountHolder Image
			FileInputStream input4 = new FileInputStream(accountHolder);
			// Complain Handler Image
			// FileInputStream input5 = new FileInputStream(complain);

			// prepare image object
			Image image = new Image(input);
			Image image1 = new Image(input1);
			Image image2 = new Image(input2);
			Image image3 = new Image(input3);
			Image image4 = new Image(input4);
			// Image image5 = new Image(input5);

			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(130);
			imageView.setY(115);
			imageView.setFitHeight(145);
			imageView.setFitWidth(150);

			// create ImageView object
			ImageView imageView1 = new ImageView(image1);
			imageView1.setX(460);
			imageView1.setY(53);
			imageView1.setFitHeight(110);
			imageView1.setFitWidth(110);

			// create ImageView object
			ImageView imageView2 = new ImageView(image2);
			imageView2.setX(640);
			imageView2.setY(62);
			imageView2.setFitHeight(100);
			imageView2.setFitWidth(100);

			// create ImageView object
			ImageView imageView3 = new ImageView(image3);
			imageView3.setX(640);
			imageView3.setY(227);
			imageView3.setFitHeight(100);
			imageView3.setFitWidth(100);

			// create ImageView object
			ImageView imageView4 = new ImageView(image4);
			imageView4.setX(460);
			imageView4.setY(224);
			imageView4.setFitHeight(100);
			imageView4.setFitWidth(100);

			root.getChildren().addAll(imageView, imageView1, imageView2, imageView3, imageView4);

			/*
			 * image added on Screen
			 */
			primaryStage.setTitle("Bank Management System");
			Image icon = new Image(it);
			primaryStage.getIcons().add(icon);

			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		Bank m = new Bank();
//		managerObj = new ManagerMainController();

		try {

			FileReader file = new FileReader(m.file);

			Scanner readLine = new Scanner(file);

			while (readLine.hasNext()) {

				User u = new User();

				String data = readLine.nextLine();
				String[] array = data.split(" ");

				u.setName(array[0]);
				u.setPassword(array[1]);
				u.setPhoneNo(array[2]);
				u.setAddress(array[3]);
				u.setCnic(array[4]);

				DatabaseLedger.getUser().add(u);
			}

			readLine.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		launch(args);
	}

	//
	//
	// ----------Admin---------------
	//
	//

//  this function is responsible to change scenes from AllUsers to Login.
	public void allUserToLoginSimple(Stage currentStage) throws IOException {

		try {
			String fxmlDocPath = fxmlPath + "Admin//LoginSimple.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane root = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(130);
			imageView.setY(100);
			imageView.setFitHeight(145);
			imageView.setFitWidth(150);
			root.getChildren().add(imageView);

			/*
			 * image added on Screen
			 */
			currentStage.setTitle("Admin Login");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//  this function is responsible to change scenes from login to SignUp.
	public void MainScreen(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Admin//MainPage.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Admin | Main Menu");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//  this function is responsible to change scenes from MainPage to SignUp.
	public void createAccount(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Admin//SignUp.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(130);
			imageView.setY(100);
			imageView.setFitHeight(145);
			imageView.setFitWidth(150);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Sign Up");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void updateAccountScreen(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Admin//UpdateAccount.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Update Account");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchAccountScreen(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Admin//SearchAccount.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Search Account");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void changePasswordScreen(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Admin//ChangePassword.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Change Password");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void viewAccountDetails(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Admin//ViewAccountDetails.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("View Account Details");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void viewTransactions(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Admin\\ViewTransaction.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("View Transaction");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void addCashier(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Admin//AddEmployeeAdmin.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Search Account");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//
	//
	// ---------Manager
	//
	//

	public void searchAccountScreenByManager(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Manager//ManagerSearchAccount.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Search Account");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void updateAccountScreenByManager(Stage currentStage) throws IOException {
//		public void updateAccountScreenByManager(Stage currentStage, class obj) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Manager//ManagerUpdateAccount.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);
//			aldncj obj= loader.getController();
//			obj.setvalue(obj);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Update Account");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void changePasswordScreenByManager(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Manager//ManagerChangePassword.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Change Password");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void viewAccountDetailsByManager(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Manager//ManagerViewAccountDetails.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("View Account Details");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void viewTransactionsByManager(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Manager//ManagerViewTransaction.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("View Transaction");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void allUserToManager(Stage currentStage) throws IOException {

		try {
			String fxmlDocPath = fxmlPath + "Manager//LoginManager.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane root = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(130);
			imageView.setY(100);
			imageView.setFitHeight(145);
			imageView.setFitWidth(150);
			root.getChildren().add(imageView);

			/*
			 * image added on Screen
			 */
			currentStage.setTitle("Manager Login");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createAccountByManager(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Manager//ManagerCreateAccount.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(130);
			imageView.setY(100);
			imageView.setFitHeight(145);
			imageView.setFitWidth(150);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Sign Up");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);

			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void MainScreenManager(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Manager//ManagerMainScreen.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Manager | Main Menu");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.setMaximized(true);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//
	//
	// --------Cashier
	//
	//

	// on cashier login --> Main For Cashier
	public void MainScreenCashier(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Cashier//CashierMainMenu.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Cashier | Main Menu");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.setMaximized(true);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// move to login for cashier
	public void MoveloginCashier(Stage currentStage) throws IOException {

		try {
			String fxmlDocPath = fxmlPath + "Cashier//LoginCashier.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane root = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(130);
			imageView.setY(100);
			imageView.setFitHeight(145);
			imageView.setFitWidth(150);
			root.getChildren().add(imageView);

			/*
			 * image added on Screen
			 */
			currentStage.setTitle("Cashier Login");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void depositMoney(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Cashier//Deposit.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Deposit");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void withdrawMoney(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Cashier//withdraw.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Withdraw");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void transferAmount(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "Cashier//TransferMoney.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Transfer Amount");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//
	//
	// Account Holder------------------------------------------
	//
	//

	// move to login for cashier
	public void MoveloginAccountHolder(Stage currentStage) throws IOException {

		try {
			String fxmlDocPath = fxmlPath + "AccountHolder//AccountHolderLogin.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane root = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(130);
			imageView.setY(100);
			imageView.setFitHeight(145);
			imageView.setFitWidth(150);
			root.getChildren().add(imageView);

			/*
			 * image added on Screen
			 */
			currentStage.setTitle("Account Holder Login");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void MoveToCheckBalance(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "AccountHolder//AccountHolderBalance.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Account Holder Balance");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void MoveToTransection(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "AccountHolder//AccountHolderTransection.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Account Holder Transection");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void MoveToUserInfo(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "AccountHolder//AccountHolderInfo.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Account Holder Balance");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// on cashier login --> Main For Cashier
	public void MainScreenAccountHolder(Stage currentStage) throws IOException {

		try {

			String fxmlDocPath = fxmlPath + "AccountHolder//AccountHolderMain.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			AnchorPane pane = (AnchorPane) loader.load(fxmlStream);

			/*
			 * Adding image on Screen
			 */
			FileInputStream input = new FileInputStream(it);
			// prepare image object
			Image image = new Image(input);
			// create ImageView object
			ImageView imageView = new ImageView(image);
			imageView.setX(60);
			imageView.setY(0);
			imageView.setFitHeight(108);
			imageView.setFitWidth(110);
			pane.getChildren().add(imageView);

			// Title and icon image added on Screen
			currentStage.setTitle("Account Holder | Main Menu");
			Image icon = new Image(it);
			currentStage.getIcons().add(icon);

			Scene scene = new Scene(pane);
			currentStage.setScene(scene);
			currentStage.setMaximized(true);
			currentStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ********************************************************
	//
	// Manager All Functions
	//
	// ********************************************************

//	ManagerChangePassword----------------------------> Manager

	public int searchAccountChangePasswordManager(String enteredAccountNo, String enteredPassword) throws IOException {

		return account.searchChangePasswordManager(enteredAccountNo, enteredPassword);
	}

	public boolean chengePasswordByManager(int index, String password) throws IOException {

		return account.chengePasswordByManager(index, password);

	}

//	ManagerSearch----------------------------> Manager

	public boolean searchOnly(String aNo) throws IOException {

		return account.searchOnly(aNo);

	}

//	ManagerSearch----------------------------> Manager

	public int searches(String aNo) throws IOException {

		return account.searches(aNo);

	}

//	ManagerUpdate----------------------------> Manager

	public int updateByManager(String phone, String address, int index) throws IOException {

		return account.updateByManager(phone, address, index);
	}

//	ManagerViewAccountDetails----------------> Manager

	Account searchViewAccountDetails(String aNo) throws IOException {

		return account.searchViewAccountDetails(aNo);
	}

//	ManagerSearch----------------------------> Manager

	public boolean viewTransactions(TableView<Transcation> data) throws IOException {

		return t.viewTransactions(data);
	}

//	ManagerSignUp----------------------------> Manager

	public int newUserRecordCheck() throws IOException {

		int result = account.newUserRecordCheck();

		return result;

	}

	public void newUserAdd(String accountNum, String dateCreation, AccountHolder accountHolder, String accountType)
			throws IOException {

		account.newUserAdd(accountNum, dateCreation, accountHolder, accountType);

	}

	public int userAdd(String accountNum, String cnicAH, String usernameAH) throws IOException {

		return account.userAdd(accountNum, cnicAH, usernameAH);
	}

	// ********************************************************
	//
	// Admin All Functions
	//
	// ********************************************************

	// addCashier----------------------------> Admin

	public boolean addnewCashier(String name, String password, String gender, String address, String cnic,
			String phoneNo, double salary, String createdDate, String username) throws IOException {

		return admin.addnewCashier(name, password, gender, address, cnic, phoneNo, salary, createdDate, username);
	}

	public int AddCashiers(String name, String password, String gender, String address, String cnic, String phoneNo,
			double salary, String createdDate, String username) {
		admin = new Admin();
		return admin.AddCashiers(name, password, gender, address, cnic, phoneNo, salary, createdDate, username);
	}

	// chanfePassword----------------------------> Admin

	public int changeAdminPassword(String enteredPassword) throws IOException {
		admin = new Admin();
		return admin.changeAdminPassword(enteredPassword);
	}

	public void passwordChanged(String password) {
		admin.passwordChanged(password);
	}

	// searchAccount----------------------------> Admin

	public int searchAccount(String aNo) throws IOException {
		return account.searchAccount(aNo);

	}

	public int check() {
		if (DatabaseLedger.accounts.isEmpty()) {
			return 0;
		}

		return 1;
	}

	// searchAccount----------------------------> Admin

	public int searchAccountIndex(String aNo) throws IOException {

		return account.searchAccountIndex(aNo);
	}

	// update----------------------------> Admin

	public int updateByAdmin(String phone, String address, int index) throws IOException {

		return account.updateByAdmin(phone, address, index);
	}

	// search for view account details ----------> Admin

	public Account accountDetails(String aNo) throws IOException {

		return account.accountDetails(aNo);
	}

	// ********************************************************
	//
	// Account Holder All Functions
	//
	// ********************************************************

	// AccountHolderBalance----------------> Account Holder

	public String Balance(int userIndex) throws IOException {

		return account.Balance(userIndex);
	}

	// AccountHolderInfo----------------> Account Holder

	public Account info() throws IOException {

		return account.info();
	}

	// AccountHolderTransactions----------> Account Holder

	public int transactionAH(TableView<Transcation> data) throws IOException {

		return t.transactionAH(data);
	}

	// ********************************************************
	//
	// Cashier All Functions
	//
	// ********************************************************

	public Account withdraw(String accountNum, String cnic) throws IOException {
		try {

			return account.withdrawSearch(accountNum, cnic);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public int withdraw(double amount, int searchIndex) {
		return account.withdraw(amount, searchIndex);
	}

	public Account deposit_Search(String accountNum, String cnic) throws IOException {
		return account.deposit_Search(accountNum, cnic);
	}

	public String transferSearch(String senderAccountNum, String reciverAccountNum) {
		return account.transferSearch(senderAccountNum, reciverAccountNum);
	}

	public int transferBalance(double amount, int sIndex, int rIndex) {
		return account.transferAmount(amount, sIndex, rIndex);
	}

	public int deposit(int searchIndex, double amount) {
		return account.deposit(searchIndex, amount);
	}
}