package application;

import java.io.IOException;

public abstract class Account {

	private String accountNumber;
	protected double balance;
	private String creationDate;
	private AccountHolder accountHolder;

	public Account() {
		this.balance = 0;
	}

	public Account(String accountNumber, String creationDate, AccountHolder accountHolder) {
		this.accountNumber = accountNumber;
		this.creationDate = creationDate;
		this.accountHolder = accountHolder;
		balance = 0;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	public double getBalance() {
		return this.balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public AccountHolder getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}

	public abstract int makeDeposit(double amount);

	public abstract int makeWithDrawal(double amount);

	public abstract int transferAmount(double amount, Account account);

	public int searchChangePasswordManager(String enteredAccountNo, String enteredPassword) throws IOException {

		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if ((DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(enteredAccountNo))
					&& (DatabaseLedger.getAccounts().get(i).getAccountHolder().getPassword().equals(enteredPassword))) {

				return i;
			}
		}

		return -1;
	}

	public boolean chengePasswordByManager(int index, String password) throws IOException {

		DatabaseLedger.getAccounts().get(index).getAccountHolder().setPassword(password);
		return true;
	}

//	ManagerSearch----------------------------> Manager

	public boolean searchOnly(String aNo) throws IOException {

		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(aNo)) {

				return true;
			}
		}

		return false;
	}

//	ManagerSearch----------------------------> Manager

	public int searches(String aNo) throws IOException {

		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(aNo)) {

				return i;
			}
		}

		return -1;
	}

//	ManagerUpdate----------------------------> Manager

	public int updateByManager(String phone, String address, int index) throws IOException {

		if ((!(phone.isEmpty()) && (!(address.isEmpty())))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setPhoneNo(phone);
			DatabaseLedger.getAccounts().get(index).getAccountHolder().setAddress(address);
			return 1;
		}

		else if ((phone.isEmpty() && (!(address.isEmpty())))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setAddress(address);
			return 2;
		}

		else if ((!(phone.isEmpty()) && (address.isEmpty()))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setPhoneNo(phone);
			return 3;
		} else {
			return -1;
		}
	}

//	ManagerViewAccountDetails----------------> Manager

	Account searchViewAccountDetails(String aNo) throws IOException {

		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(aNo)) {

				return DatabaseLedger.getAccounts().get(i);
			}
		}
		return null;
	}

//	ManagerSignUp----------------------------> Manager

	public int newUserRecordCheck() throws IOException {
		if (DatabaseLedger.getAccounts().isEmpty()) {
			return 0;
		} else {
			return 1;
		}
	}

	public void newUserAdd(String accountNum, String dateCreation, AccountHolder accountHolder, String accountType)
			throws IOException {

		if (accountType.equalsIgnoreCase("saving")) {
			DatabaseLedger.getAccounts().add(new SavingAccount(accountNum, dateCreation, accountHolder));
		}

		else if (accountType.equalsIgnoreCase("checking")) {
			DatabaseLedger.getAccounts().add(new CheckingAccount(accountNum, dateCreation, (AccountHolder) accountHolder));
		}

	}

	public int userAdd(String accountNum, String cnicAH, String usernameAH) throws IOException {

		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(accountNum)) {
				return 0;
			}

			if (DatabaseLedger.getAccounts().get(i).getAccountHolder().getCnic().equals(cnicAH)) {
				return 1;
			}

			if (DatabaseLedger.getAccounts().get(i).getAccountHolder().getUsername().equals(usernameAH)) {
				return 2;
			}
		}
		return -1;
	}

	// searchAccount----------------------------> Admin

	public int searchAccount(String aNo) throws IOException {
		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(aNo)) {
				return 1;
			}

		}
		return 0;
	}

	// searchAccount----------------------------> Admin

	public int searchAccountIndex(String aNo) throws IOException {
		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(aNo)) {
				return i;
			}

		}
		return -1;
	}

	// update----------------------------> Admin

	public int updateByAdmin(String phone, String address, int index) throws IOException {

		if ((!(phone.isEmpty()) && (!(address.isEmpty())))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setPhoneNo(phone);
			DatabaseLedger.getAccounts().get(index).getAccountHolder().setAddress(address);
			return 1;
		}

		else if ((phone.isEmpty() && (!(address.isEmpty())))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setAddress(address);
			return 2;
		}

		else if ((!(phone.isEmpty()) && (address.isEmpty()))) {

			DatabaseLedger.getAccounts().get(index).getAccountHolder().setPhoneNo(phone);
			return 3;
		} else {
			return 4;
		}
	}

	// search for view account details ----------> Admin

	public Account accountDetails(String aNo) throws IOException {

		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(aNo)) {

				return DatabaseLedger.getAccounts().get(i);

			}
		}

		return null;
	}

	// AccountHolderBalance----------------> Account Holder

	public String Balance(int userIndex) throws IOException {

		return Double.toString(DatabaseLedger.getAccounts().get(userIndex).getBalance());
	}

	// AccountHolderInfo----------------> Account Holder

	public Account info() throws IOException {

		int i = LoginAccountHolder.index;

		return DatabaseLedger.getAccounts().get(i);

	}

	public Account withdrawSearch(String accountNum, String cnic) throws IOException {
		try {

			if ((!(accountNum.isEmpty())) && (cnic.isEmpty())) {

				for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {
					if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(accountNum)) {
						WithdrawController.searchIndex = i;
						return DatabaseLedger.getAccounts().get(i);
					}
				}
			}

			else if ((accountNum.isEmpty()) && (!(cnic.isEmpty()))) {

				for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

					if (DatabaseLedger.getAccounts().get(i).getAccountHolder().getCnic().equals(cnic)) {
						WithdrawController.searchIndex = i;
						return DatabaseLedger.getAccounts().get(i);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public int withdraw(double amount, int searchIndex) {

		int result = DatabaseLedger.getAccounts().get(searchIndex).makeWithDrawal(amount);
		return result;
	}

	public Account deposit_Search(String accountNum, String cnic) throws IOException {

		if ((!(accountNum.isEmpty())) && (cnic.isEmpty())) {

			for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {
				if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(accountNum)) {

					DepositController.searchIndex = i;
					return DatabaseLedger.getAccounts().get(i);
				}
			}
		}

		else if ((accountNum.isEmpty()) && (!(cnic.isEmpty()))) {

			for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

				if (DatabaseLedger.getAccounts().get(i).getAccountHolder().getCnic().equals(cnic)) {

					DepositController.searchIndex = i;
					return DatabaseLedger.getAccounts().get(i);
				}
			}
		}

		return null;

	}

	public String transferSearch(String senderAccountNum, String reciverAccountNum) {
		String balance = "0.0";

		for (int i = 0; i < DatabaseLedger.getAccounts().size(); i++) {

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(reciverAccountNum)) {
				TransferMoneyController.rIndex = i;
			}

			if (DatabaseLedger.getAccounts().get(i).getAccountNumber().equals(senderAccountNum)) {
				TransferMoneyController.sIndex = i;
				balance = String.valueOf(DatabaseLedger.getAccounts().get(i).balance);
			}
		}
		return balance;
	}

	public int transferAmount(double amount, int sIndex, int rIndex) {
		return DatabaseLedger.getAccounts().get(sIndex).transferAmount(amount,
				DatabaseLedger.getAccounts().get(rIndex));
	}

	public int deposit(int searchIndex, double amount) {

		if (DatabaseLedger.getAccounts().size() > searchIndex) {
			
			return DatabaseLedger.getAccounts().get(searchIndex).makeDeposit(amount);
		}
		
		return -1;
	}

}
