package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginManager {

	Bank m= new Bank();
	
    @FXML
    private Button cancel;

    @FXML
    private PasswordField passwordLogin;

    @FXML
    private Label passwordErrorLogin;

    @FXML
    private TextField usernameLogin;

    @FXML
    private Button login;

    @FXML
    void mainPageOfManager(ActionEvent event) throws IOException {

    	// String name, String password, String phoneNo, String address, String cnic
    	
    	String name = usernameLogin.getText();

		String pass = passwordLogin.getText();

		System.out.println(name + "," + pass);

		boolean check = false;

		for (int i = 0; i < DatabaseLedger.getUser().size(); i++) {

			if ((DatabaseLedger.getUser().get(i).getName().equals(name))
					&& (DatabaseLedger.getUser().get(i).getPassword().equals(pass))) {

				check = true;

				// the stage can be accessed using action event source Stage s = (Stage)
				Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

				m.MainScreenManager(s);
			}

		}

		if (check == false) {
			passwordErrorLogin.setText("Username/Password is not correct");
		}
	}	
    	
    
	@FXML
	public void start(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.start(s);

	}

}