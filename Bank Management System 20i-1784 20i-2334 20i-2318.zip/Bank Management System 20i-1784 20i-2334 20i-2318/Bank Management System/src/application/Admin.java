package application;

import java.io.IOException;

public class Admin {

	private String name = "usman";

	private static String password = "12345";

	private String phoneNo = "03010101024";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		Admin.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	// addCashier----------------------------> Admin
	
	public boolean addnewCashier(String name, String password, String gender, String address, String cnic,
			String phoneNo, double salary, String createdDate, String username) throws IOException {

		if (DatabaseLedger.getCashier().isEmpty()) {

			Cashier c = new Cashier(name, password, gender, address, cnic, phoneNo, salary, createdDate, username);

			DatabaseLedger.cashier.add(c);
			return true;
		}

		return false;
	}
	
	public int AddCashiers(String name, String password, String gender, String address, String cnic, String phoneNo,
			double salary, String createdDate, String username) {

		for (int i = 0; i < DatabaseLedger.getCashier().size(); i++) {

			if (DatabaseLedger.getCashier().get(i).getCnic().equals(cnic)) {
				return 1;
			}

			if (DatabaseLedger.getCashier().get(i).getUsername().equals(username)) {
				return 2;
			}
		}

		Cashier c = new Cashier(name, password, gender, address, cnic, phoneNo, salary, createdDate, username);

		DatabaseLedger.cashier.add(c);
		return -1;
	}
	
	// chanfePassword----------------------------> Admin

	public int changeAdminPassword(String enteredPassword) throws IOException {

		if (DatabaseLedger.user.get(0).getPassword().equals(enteredPassword)) {
			return 1;
		}

		return 0;
	}
	
	public void passwordChanged(String password) {
		
		DatabaseLedger.getUser().get(0).setPassword(password);
		
	}
	
}
