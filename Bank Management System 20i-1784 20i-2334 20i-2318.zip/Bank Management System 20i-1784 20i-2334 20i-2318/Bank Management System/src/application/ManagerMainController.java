package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;

public class ManagerMainController {

	boolean check = false;

	Bank m = new Bank();

	int index, indexLocation = -1;

	boolean checks = false;

	@FXML
	private Button logout;

	@FXML
	private Button viewAccountDetails;

	@FXML
	private Button viewTransection;

	@FXML
	private Button createAccount;

	@FXML
	private Button updateAccount;

	@FXML
	private Button searchAccount;

	@FXML
	private Button changePassword;

	@FXML
	void moveToUpdateAccount(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.updateAccountScreenByManager(s);
	}

	@FXML
	void searchAccount(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.searchAccountScreenByManager(s);
	}

	@FXML
	void changePassword(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.changePasswordScreenByManager(s);
	}

	@FXML
	void viewTransections(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.viewTransactionsByManager(s);
	}

	@FXML
	void moveToViewAccountDetails(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.viewAccountDetailsByManager(s);
	}

	@FXML
	void start(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.start(s);
	}

	@FXML
	void createAccounts(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.createAccountByManager(s);
	}

	//
	//
	//
	//
	// --------------ChangePassword--------------

	@FXML
	private PasswordField newPassword;

	@FXML
	private PasswordField confirmPassword;

	@FXML
	private Button back;

	@FXML
	private Label currentPasswordError;

	@FXML
	private Button savePassword;

	@FXML
	private Label confirmPasswordError;

	@FXML
	private Label newPasswordError;

	@FXML
	private PasswordField currentPassword;

	@FXML
	private Label confirmationMessage;

	@FXML
	private PasswordField currentPassword1;

	@FXML
	private Button savePassword1;

	@FXML
	private TextField accountNumberCP;

	@FXML
	private Label confirmationFound;

	@FXML
	void searchAccountForChangePassword(ActionEvent event) {
		try {

			String enteredAccountNo = accountNumberCP.getText();
			String enteredPassword = currentPassword.getText();

			indexLocation = -1;

			int check = m.check();
			
			if (check == 0) {
				currentPasswordError.setText("No rocord found to update.");
			} else {

				indexLocation = m.searchAccountChangePasswordManager(enteredAccountNo, enteredPassword);

			}

			if (indexLocation >= 0) {
				confirmationFound.setText("Account Found, now you can change your password.");
				confirmationMessage.setText(" ");
			} else {
				confirmationFound.setText("Account Not Found, please enter credentials again.");
				confirmationMessage.setText(" ");
			}

		} catch (

		Exception e) {
			e.printStackTrace();
		}

	}

	@FXML
	void saveChangePassword(ActionEvent event) throws IOException {

		if (indexLocation >= 0) {

			if (!(newPassword.getText().isBlank()) && (!(confirmPassword.getText().isBlank()))) {

				if (newPassword.getText().equals(confirmPassword.getText())) {

					boolean result = m.chengePasswordByManager(indexLocation, confirmPassword.getText());

					if (result == true) {
						confirmPasswordError.setText(" ");
						confirmationMessage.setText("Password updated successfully.");
					}

				} else {
					confirmPasswordError.setText("Password doesn't match with new password.");
				}

			} else {
				confirmationMessage.setText("Please fill out all fields.");
			}
		}

	}

	@FXML
	void backToMain(ActionEvent event) throws IOException {
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MainScreenManager(s);
	}

	//
	//
	//
	//
	// ---------------------Search Account------------

	@FXML
	private Button searchUA;

	@FXML
	private Label messageIfAccNotFound;

	@FXML
	private TextField accountNumberUA;

	@FXML
	private Label accountFound;

	@FXML
	void searchOnly(ActionEvent event) throws IOException {

		String aNo = accountNumberUA.getText();

		index = -1;

		if (!(aNo.isBlank())) {

			boolean flag = m.searchOnly(aNo);

			if (flag == true) {
				accountFound.setText("Account Found.");
				return;
			} else {
				accountFound.setText("Account Not Found.");
				return;
			}

//			messageIfAccNotFound.setText("No Account exists with account Number: " + aNo);

		} else {
			messageIfAccNotFound.setText("Please Enter Account Number");
		}
	}

	//
	//
	//
	//
	// --------------------------UpdateAccount----------------
	@FXML
	private TextField addressUA;

	@FXML
	private Button updateUA;

	@FXML
	private TextField phoneUA;

	@FXML
	private Label updatedSuccessfull;

	@FXML
	void search(ActionEvent event) throws IOException {

		String aNo = accountNumberUA.getText();

		index = -1;

		if (!(aNo.isBlank())) {

			index = m.searches(aNo);

			if (index != -1)
				messageIfAccNotFound.setText("Account found");
			else
				messageIfAccNotFound.setText("Account not found");
		} else {
			messageIfAccNotFound.setText("Please Enter Account Number");
		}
	}

	@FXML
	private Label successfullyUpdated;

	@FXML
	void update(ActionEvent event) throws IOException {

		String phone = phoneUA.getText();
		String address = addressUA.getText();

		int result = m.updateByManager(phone, address, index);

		if (result == 1 || result == 2 || result == 3) {
			successfullyUpdated.setText("Successfully Updated.");
		}

		else {
			successfullyUpdated.setText("please fill out the fields ");
		}
	}

	//
	//
	//
	//
	// ------------------View Account Details-----------------------

	@FXML
	private Label creationDateVAD;

	@FXML
	private Label accountTypeVAD;

	@FXML
	private TextField AccountNumberOfVAD;

	@FXML
	private Label messageIfAccNotFoundVAD;

	@FXML
	private Label dateOfBirthVAD;

	@FXML
	private Label accountNumberVAD;

	@FXML
	private Label addressVAD;

	@FXML
	private Button searchVAD;

	@FXML
	private Label genderVAD;

	@FXML
	private Label usernameVAD;

	@FXML
	private Label phoneVAD;

	@FXML
	void searchVAD(ActionEvent event) throws IOException {

		String aNo = AccountNumberOfVAD.getText();

		if (!(aNo.isBlank())) {

			Account i = m.searchViewAccountDetails(aNo);

			if (i != null) {

				usernameVAD.setText(i.getAccountHolder().getUsername());
				accountNumberVAD.setText(i.getAccountHolder().getAccountNumber());
				accountTypeVAD.setText(i.getAccountHolder().getAccountType());
				genderVAD.setText(i.getAccountHolder().getGender());
				dateOfBirthVAD.setText(i.getAccountHolder().getDateOfBirth());
				creationDateVAD.setText(i.getAccountHolder().getCreationDate());
				addressVAD.setText(i.getAccountHolder().getAddress());
				phoneVAD.setText(i.getAccountHolder().getPhoneNo());

				messageIfAccNotFoundVAD.setText("Account Found");
			} else {
				usernameVAD.setText(" ");
				accountNumberVAD.setText(" ");
				accountTypeVAD.setText(" ");
				genderVAD.setText(" ");
				dateOfBirthVAD.setText("");
				creationDateVAD.setText("");
				addressVAD.setText("");
				phoneVAD.setText("");
				
				messageIfAccNotFoundVAD.setText("No Account exists with Account Number: " + aNo);
			}
		} else {
			messageIfAccNotFoundVAD.setText("Please Enter Account Number");
		}

	}

	//
	//
	//
	//
	// ------------------View Transaction-----------------------
	//
	//
	//
	@FXML
	TableView<Transcation> data = new TableView<Transcation>();

	@FXML
	private TableColumn<Transcation, String> accountType;

	@FXML
	private TableColumn<Transcation, Double> amount;

	@FXML
	private TableColumn<Transcation, String> transectionDate;

	@FXML
	private TableColumn<Transcation, String> username;

	@FXML
	private TableColumn<Transcation, String> accountNo;

	@FXML
	private TableColumn<Transcation, String> transaction_Type;

	@FXML
	private Label noDataFoundFortransaction;

	@FXML
	private Button show;

	public void addtableViewData() throws IOException {

		if (check == false) {

			accountType = new TableColumn<Transcation, String>("   Account Type   ");
			amount = new TableColumn<Transcation, Double>("Transected Account");
			username = new TableColumn<Transcation, String>("     Username     ");
			transectionDate = new TableColumn<Transcation, String>(" Transection Date ");
			accountNo = new TableColumn<Transcation, String>("  Account Number  ");
			transaction_Type = new TableColumn<Transcation, String>(" Transaction Type ");

			accountNo.setCellValueFactory(new PropertyValueFactory<Transcation, String>("accountNumber"));
			accountNo.setCellFactory(TextFieldTableCell.forTableColumn());
			username.setCellValueFactory(new PropertyValueFactory<Transcation, String>("customerName"));
			username.setCellFactory(TextFieldTableCell.forTableColumn());
			accountType.setCellValueFactory(new PropertyValueFactory<Transcation, String>("accountType"));
			accountType.setCellFactory(TextFieldTableCell.forTableColumn());
			transaction_Type.setCellValueFactory(new PropertyValueFactory<Transcation, String>("transcationType"));
			transaction_Type.setCellFactory(TextFieldTableCell.forTableColumn());
			amount.setCellValueFactory(new PropertyValueFactory<Transcation, Double>("amount"));
			amount.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
			transectionDate.setCellValueFactory(new PropertyValueFactory<Transcation, String>("date"));
			transectionDate.setCellFactory(TextFieldTableCell.forTableColumn());

			data.getColumns().add(accountNo);
			data.getColumns().add(username);
			data.getColumns().add(accountType);
			data.getColumns().add(transaction_Type);
			data.getColumns().add(amount);
			data.getColumns().add(transectionDate);

			accountNo.prefWidthProperty().bind(data.widthProperty().multiply(0.15));
			username.prefWidthProperty().bind(data.widthProperty().multiply(0.15));
			accountType.prefWidthProperty().bind(data.widthProperty().multiply(0.16));
			transaction_Type.prefWidthProperty().bind(data.widthProperty().multiply(0.17));
			amount.prefWidthProperty().bind(data.widthProperty().multiply(0.17));
			transectionDate.prefWidthProperty().bind(data.widthProperty().multiply(0.2));

			transectionDate.setResizable(false);
			amount.setResizable(false);
			transaction_Type.setResizable(false);
			accountType.setResizable(false);
			username.setResizable(false);
			accountNo.setResizable(false);

			check = true;
		}

		boolean check = m.viewTransactions(data);

		if (check == false) {
			noDataFoundFortransaction.setText("No record found to display.");
		}

	}

}
