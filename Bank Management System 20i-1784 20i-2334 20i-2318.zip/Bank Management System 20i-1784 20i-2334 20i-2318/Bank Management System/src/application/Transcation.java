package application;

import java.io.IOException;

import javafx.scene.control.TableView;

public class Transcation {
	private double amount, fee;
	private String transcationType, date, customerName, accountNumber, RecieverCustomername, RecieverAccountNumber,
			accountType, recieverAccountType;

	public Transcation() {}
	
	public Transcation(String customerName, String accountNumber, String accountType, String transcationType,
			String date, double amount, double fee) {
		this.customerName = customerName;
		this.accountNumber = accountNumber;
		this.transcationType = transcationType;
		this.date = date;
		this.amount = amount;
		this.fee = fee;
		this.accountType = accountType;
	}

	public Transcation(String customerName, String accountNumber, String accountType, String transcationType,
			String date, double amount) {
		this.customerName = customerName;
		this.accountNumber = accountNumber;
		this.transcationType = transcationType;
		this.date = date;
		this.amount = amount;
		this.accountType = accountType;
	}

	public Transcation(String customerName, String accountNumber, String accountType, String transcationType,
			String date, double amount, String recieverCustomerName, String recieverAccountNumber,
			String recieverAccountType) {
		this.customerName = customerName;
		this.accountNumber = accountNumber;
		this.transcationType = transcationType;
		this.date = date;
		this.amount = amount;
		this.RecieverCustomername = recieverCustomerName;
		this.RecieverAccountNumber = recieverAccountNumber;
		this.accountType = accountType;
		this.recieverAccountType = recieverAccountType;
	}

	public String getRecieverAccountType() {
		return recieverAccountType;
	}

	public void setRecieverAccountType(String recieverAccountType) {
		this.recieverAccountType = recieverAccountType;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getRecieverCustomername() {
		return RecieverCustomername;
	}

	public void setRecieverCustomername(String recieverCustomername) {
		RecieverCustomername = recieverCustomername;
	}

	public String getRecieverAccountNumber() {
		return RecieverAccountNumber;
	}

	public void setRecieverAccountNumber(String recieverAccountNumber) {
		RecieverAccountNumber = recieverAccountNumber;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Customer Name = " + getCustomerName() + ", AccountNumber = " + getAccountNumber()
				+ ", TranscationType = " + getTranscationType() + ", Amount = " + getAmount() + ", Date = " + getDate();
	}

	
//	ManagerSearch----------------------------> Manager

	public boolean viewTransactions(TableView<Transcation> data) throws IOException {

		if (DatabaseLedger.getTranscation().isEmpty()) {
			return false;
		} else {

			for (int i = 0; i < DatabaseLedger.getTranscation().size(); i++) {
				
				data.getItems().add(DatabaseLedger.getTranscation().get(i));
			}
			return true;
		}
	}
	
	
	// AccountHolderTransactions----------> Account Holder

	public int transactionAH(TableView<Transcation> data) throws IOException {

		int count = 0;

		String username = LoginAccountHolder.usernameTrack;

		for (int i = 0; i < DatabaseLedger.transcation.size(); i++) {

			System.out.println(DatabaseLedger.getTranscation().get(i).getCustomerName());

			if (DatabaseLedger.transcation.get(i).getCustomerName().equals(username)) {
				System.out.println("in");
				
				data.getItems().add(DatabaseLedger.getTranscation().get(i));
			
				count++;
			}
		}

		return count;
	}

	
}
