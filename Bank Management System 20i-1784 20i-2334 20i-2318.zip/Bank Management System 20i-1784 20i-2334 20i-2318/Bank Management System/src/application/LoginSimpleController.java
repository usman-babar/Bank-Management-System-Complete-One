
// MainScreen is for admin

package application;

import java.io.IOException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginSimpleController {
	Bank m = new Bank();

	@FXML
	public Button cancel;

	@FXML
	public Button login;

	@FXML
	private PasswordField password;

	@FXML
	private TextField username;

	@FXML
	private Label passwordError;

	@FXML
	private Label usernameError;

	public LoginSimpleController() {

	}

	@FXML
	public ResourceBundle resources;

	@FXML
	public void initialize() {
	}

	@FXML
	public void start(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.start(s);

	}

	@FXML
	public void mainPage(ActionEvent event) throws IOException {

		String name = username.getText();

		String pass = password.getText();

		System.out.println(name + "," + DatabaseLedger.getUser().get(0).getName());

		if ((DatabaseLedger.getUser().get(0).getName().equals("usman")) && (DatabaseLedger.getUser().get(0).getPassword().equals(pass))) {

			// the stage can be accessed using action event source Stage s = (Stage)
			Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

			m.MainScreen(s);
		}
		
		if (!(DatabaseLedger.getUser().get(0).getName().equals(name))) {

			usernameError.setText("Username is not correct");
		}
		
		if (DatabaseLedger.getUser().get(0).getName().equals(name)) {

			usernameError.setText("");
		}

		if (!(DatabaseLedger.getUser().get(0).getPassword().equals(pass))) {

			passwordError.setText("Password is not correct");
		}
		
		if (DatabaseLedger.getUser().get(0).getPassword().equals(pass)) {

			passwordError.setText("");
		}

		/*
		 * else { System.out.println("ERROR"); Alert alert = new Alert(AlertType.ERROR,
		 * "username or password is not correct."); alert.showAndWait(); }
		 */

	}

}
