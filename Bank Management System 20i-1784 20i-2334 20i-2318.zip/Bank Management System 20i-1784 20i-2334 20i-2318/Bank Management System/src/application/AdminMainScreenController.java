package application;

import java.io.IOException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;

public class AdminMainScreenController {

	boolean check = false;

	Bank m = new Bank();

	int index = 0;

	@FXML
	private Button back;

	@FXML
	private Button logout;

	@FXML
	private Button createAccount;

	@FXML
	private Button balanceView;

	@FXML
	private Button viewAccountDetails;

	@FXML
	private TextField addressUA;

	@FXML
	private Button updateUA;

	@FXML
	private Button searchUA;

	@FXML
	private TextField phoneUA;

	@FXML
	private Label messageIfAccNotFound;

	@FXML
	private Button searchAccount;

	@FXML
	private TextField cnicUA;

	@FXML
	private TextField AccountNumberUA;

	@FXML
	private Label accountFound;

	@FXML
	private Label accountNumberVAD;

	@FXML
	private Button changePassword;

	@FXML
	private PasswordField newPassword;

	@FXML
	private PasswordField confirmPassword;

	@FXML
	private Label currentPasswordError;

	@FXML
	private Label confirmationMessage;

	@FXML
	private Button savePassword;

	@FXML
	private Label confirmPasswordError;

	@FXML
	private Label newPasswordError;

	@FXML
	private PasswordField currentPassword;

	@FXML
	private Label creationDateVAD;

	@FXML
	private Label accountTypeVAD;

	@FXML
	private Label dateOfBirthVAD;

	@FXML
	private TextField account_NumberVAD;

	@FXML
	private Label addressVAD;

	@FXML
	private Button searchVAD;

	@FXML
	private Label genderVAD;

	@FXML
	private Label usernameVAD;

	@FXML
	private TextField cnicVAD;

	@FXML
	private Label phoneNumberVAD;

	@FXML
	private Label messageIfAccNotFoundVAD;

	@FXML
	private Button view;

	// Add Employee TextFields

	@FXML
	private PasswordField EmployeePassword;

	@FXML
	private TextField EmployeeGender;

	@FXML
	private TextField EmployeeCnic;

	@FXML
	private PasswordField EmployeeConfirmPassword;

	@FXML
	private TextField EmployeePhoneNumber;

	@FXML
	private TextField EmployeeAddress;

	@FXML
	private TextField EmployeeName;

	@FXML
	private TextField EmployeeUserName;

	@FXML
	private TextField EmployeeSalary;

	@FXML
	private TextField EmployeeHireDate;

	@FXML
	private Label EmployeeCNICError;

	@FXML
	private Button add;

	@FXML
	private Button addEmployeeCashier;

	@FXML
	private Label ErrorAddCashier;

	@FXML
	private Label updatedSuccessfull;

	@FXML
	private Label EmployeeUserNameError;

	@FXML
	private Label EmployeeConfirmPasswordError;

	@FXML
	private Button show;

	@FXML
	private Button viewTransaction;

	@FXML
	TableView<Transcation> data = new TableView<Transcation>();

	@FXML
	private TableColumn<Transcation, String> accountType;

	@FXML
	private TableColumn<Transcation, Double> amount;

	@FXML
	private TableColumn<Transcation, String> transectionDate;

	@FXML
	private TableColumn<Transcation, String> username;

	@FXML
	private TableColumn<Transcation, String> accountNo;

	@FXML
	private TableColumn<Transcation, String> transaction_Type;

	@FXML
	private Label noDataFoundFortransaction;

	@FXML
	private Label CashierAddedSuccessfully;

	public AdminMainScreenController() {
	}

	@FXML
	public ResourceBundle resources;

	@FXML
	public void initialize() {
	}

	@FXML
	public void start(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.start(s);

	}

	@FXML
	void backToMain(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.MainScreen(s);

	}

	@FXML
	public void createAccounts(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.createAccount(s);

	}

	@FXML
	void moveToUpdateAccount(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.updateAccountScreen(s);
	}

	@FXML
	void searchAccount(ActionEvent event) throws IOException {

		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.searchAccountScreen(s);
	}

	@FXML
	void changePassword(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.changePasswordScreen(s);
	}

	@FXML
	void viewTransaction(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.viewTransactions(s);
	}

	@FXML
	void moveToViewAccountDetails(ActionEvent event) throws IOException {

		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();

		m.viewAccountDetails(s);
	}

	@FXML
	void searchVAD(ActionEvent event) throws IOException {

		String aNo = account_NumberVAD.getText();

		if (!(aNo.isBlank())) {

			Account account = m.accountDetails(aNo);

			try {

				if (account != null) {
					usernameVAD.setText(account.getAccountHolder().getUsername());
					accountNumberVAD.setText(aNo);
					phoneNumberVAD.setText(account.getAccountHolder().getPhoneNo());
					accountTypeVAD.setText(account.getAccountHolder().getAccountType());
					genderVAD.setText(account.getAccountHolder().getGender());
					dateOfBirthVAD.setText(account.getAccountHolder().getDateOfBirth());
					creationDateVAD.setText(account.getAccountHolder().getCreationDate());
					addressVAD.setText(account.getAccountHolder().getAddress());

					messageIfAccNotFoundVAD.setText("Account Found");
					return;
				}

				else {
					usernameVAD.setText(" ");
					accountNumberVAD.setText(" ");
					accountTypeVAD.setText(" ");
					genderVAD.setText(" ");
					phoneNumberVAD.setText(" ");
					dateOfBirthVAD.setText(" ");
					creationDateVAD.setText(" ");
					addressVAD.setText(" ");

					messageIfAccNotFoundVAD.setText("No Account exists with Account Number: " + aNo);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			messageIfAccNotFoundVAD.setText("Please Enter Account Number");
		}
	}

	@FXML
	void saveChangePassword(ActionEvent event) throws IOException {

		String enteredPassword = currentPassword.getText();

		if (!(enteredPassword.isBlank())) {

			int result = m.changeAdminPassword(enteredPassword);

			if (result == 1) {
				currentPasswordError.setText("Password matched.");

				if ((!(newPassword.getText().isBlank())) && (!(confirmPassword.getText().isBlank()))) {

					if (newPassword.getText().equals(confirmPassword.getText())) {

						m.passwordChanged(newPassword.getText());
						confirmationMessage.setText("Password changed successfully.");

						confirmPasswordError.setText(" ");

					} else {
						confirmPasswordError.setText("password doesn't match.");
					}
				}

				else if ((newPassword.getText().isBlank()) && (!(confirmPassword.getText().isBlank()))) {
					newPasswordError.setText("Please enter new password first.");
				}

				else if ((!(newPassword.getText().isBlank())) && (confirmPassword.getText().isBlank())) {
					confirmPasswordError.setText("Please confirm password first.");
				} else {
					newPasswordError.setText("Please enter new password first.");
					confirmPasswordError.setText("Please confirm password first.");
				}

			} else {
				currentPasswordError.setText("Wrong password.");
			}
		} else {
			currentPasswordError.setText("Please enter password first.");
		}
	}

	@FXML
	void searchOnly(ActionEvent event) throws IOException {

		index = -1;
		String aNo = AccountNumberUA.getText();

		if ((!(aNo.isBlank()))) {

			int result = m.searchAccount(aNo);

			if (result == 1) {
				accountFound.setText("Account Found.");
				messageIfAccNotFound.setText(" ");
			} else {
				accountFound.setText(" ");
				messageIfAccNotFound.setText("No Account exists with Account Number: " + aNo);
			}
		} else {
			messageIfAccNotFound.setText("Please Enter Account Number");
		}
	}

	@FXML
	void search(ActionEvent event) throws IOException {

		index = -1;
		String aNo = AccountNumberUA.getText();

		if (!(aNo.isBlank())) {

			index = m.searchAccountIndex(aNo);

			if (index != -1) {
				accountFound.setText("Account Found, Update Fileds");
				messageIfAccNotFound.setText("");
			} else {
				accountFound.setText(" ");
				messageIfAccNotFound.setText("No Account exists with Account Number: " + aNo);
			}

		} else {
			messageIfAccNotFound.setText("Please Enter Account Number");
		}
	}

	@FXML
	void update(ActionEvent event) throws IOException {

		String phone = phoneUA.getText();
		String address = addressUA.getText();

		int result = m.updateByAdmin(phone, address, index);

		if (result == 1 || result == 2 || result == 3) {
			updatedSuccessfull.setText("Successfully Updated.");
		} else {
			updatedSuccessfull.setText("No new record enter.");
		}
	}

	@FXML
	void addEmployee(ActionEvent event) throws IOException {
		// the stage can be accessed using action event source
		Stage s = (Stage) ((Node) event.getSource()).getScene().getWindow();
		m.addCashier(s);
	}

	@FXML
	void addCashier(ActionEvent event) throws IOException {

		if (!(EmployeeName.getText().isBlank()) && (!(EmployeeUserName.getText().isBlank()))
				&& (!(EmployeePassword.getText().isBlank())) && (!(EmployeeConfirmPassword.getText().isBlank()))
				&& (!(EmployeePhoneNumber.getText().isBlank())) && (!(EmployeeCnic.getText().isBlank()))
				&& (!(EmployeeGender.getText().isBlank())) && (!(EmployeeSalary.getText().isBlank()))
				&& (!(EmployeeHireDate.getText().isBlank())) && (!(EmployeeAddress.getText().isBlank()))) {

			double salary = Double.parseDouble(EmployeeSalary.getText());

			if (EmployeePassword.getText().equals(EmployeeConfirmPassword.getText())) {

				boolean flag = m.addnewCashier(EmployeeName.getText(), EmployeePassword.getText(),
						EmployeeGender.getText(), EmployeeAddress.getText(), EmployeeCnic.getText(),
						EmployeePhoneNumber.getText(), salary, EmployeeHireDate.getText(), EmployeeUserName.getText());

				if (flag == true) {
					ErrorAddCashier.setText(" ");
					CashierAddedSuccessfully.setText("Cashier added successfully.");
				}

				else {

					int result = m.AddCashiers(EmployeeName.getText(), EmployeePassword.getText(),
							EmployeeGender.getText(), EmployeeAddress.getText(), EmployeeCnic.getText(),
							EmployeePhoneNumber.getText(), salary, EmployeeHireDate.getText(),
							EmployeeUserName.getText());

					if (result == 1) {
						EmployeeCNICError.setText("CNIC already exist.");
					} else if (result == 2) {
						EmployeeUserNameError.setText("Username already exist.");
					} else if (result == -1) {
						CashierAddedSuccessfully.setText("Cashier added successfully.");
					}

				}
			} else {
				EmployeeConfirmPasswordError.setText("Password doesn't match.");
			}

		} else {
			ErrorAddCashier.setText("Please fill out all fields.");
		}

	}

	// view Transaction

	public void addtableViewData() throws IOException {

		if (check == false) {

			accountType = new TableColumn<Transcation, String>("   Account Type   ");
			amount = new TableColumn<Transcation, Double>("Transected Account");
			username = new TableColumn<Transcation, String>("     Username     ");
			transectionDate = new TableColumn<Transcation, String>(" Transection Date ");
			accountNo = new TableColumn<Transcation, String>("  Account Number  ");
			transaction_Type = new TableColumn<Transcation, String>(" Transaction Type ");

			accountNo.setCellValueFactory(new PropertyValueFactory<Transcation, String>("accountNumber"));
			accountNo.setCellFactory(TextFieldTableCell.forTableColumn());
			username.setCellValueFactory(new PropertyValueFactory<Transcation, String>("customerName"));
			username.setCellFactory(TextFieldTableCell.forTableColumn());
			accountType.setCellValueFactory(new PropertyValueFactory<Transcation, String>("accountType"));
			accountType.setCellFactory(TextFieldTableCell.forTableColumn());
			transaction_Type.setCellValueFactory(new PropertyValueFactory<Transcation, String>("transcationType"));
			transaction_Type.setCellFactory(TextFieldTableCell.forTableColumn());
			amount.setCellValueFactory(new PropertyValueFactory<Transcation, Double>("amount"));
			amount.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
			transectionDate.setCellValueFactory(new PropertyValueFactory<Transcation, String>("date"));
			transectionDate.setCellFactory(TextFieldTableCell.forTableColumn());

			data.getColumns().add(accountNo);
			data.getColumns().add(username);
			data.getColumns().add(accountType);
			data.getColumns().add(transaction_Type);
			data.getColumns().add(amount);
			data.getColumns().add(transectionDate);

			accountNo.prefWidthProperty().bind(data.widthProperty().multiply(0.15));
			username.prefWidthProperty().bind(data.widthProperty().multiply(0.15));
			accountType.prefWidthProperty().bind(data.widthProperty().multiply(0.16));
			transaction_Type.prefWidthProperty().bind(data.widthProperty().multiply(0.17));
			amount.prefWidthProperty().bind(data.widthProperty().multiply(0.17));
			transectionDate.prefWidthProperty().bind(data.widthProperty().multiply(0.2));

			transectionDate.setResizable(false);
			amount.setResizable(false);
			transaction_Type.setResizable(false);
			accountType.setResizable(false);
			username.setResizable(false);
			accountNo.setResizable(false);

			check = true;
		}

		boolean check = m.viewTransactions(data);

		if (check == false) {
			noDataFoundFortransaction.setText("No record found to display.");
		}

	}

}